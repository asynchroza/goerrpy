from goerrpy.decorators import goerr

__all__ = [
    "goerr"
]